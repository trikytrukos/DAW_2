var contenedor = document.getElementById('contenedor');
contenedor.addEventListener('click', function(event) {
    alert('Tipo de evento: ' + event.type);
});