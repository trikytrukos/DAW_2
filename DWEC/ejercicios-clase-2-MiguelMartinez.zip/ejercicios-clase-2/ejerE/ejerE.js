function cambiarEstilo(){
    document.getElementById("contenedor").style.backgroundColor="#fc0000";
    document.getElementById("parrafo").style.fontSize="20px";
    document.getElementById("parrafo").style.color="#fff";
    document.getElementById("boton").style.backgroundColor="#4bade2";
    document.getElementById("boton").style.color="#fff";

}