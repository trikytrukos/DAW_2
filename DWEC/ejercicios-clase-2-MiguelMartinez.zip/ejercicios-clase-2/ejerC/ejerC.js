function cambiarContenido(){
    document.getElementById("textoInicial").value="¡El contenido ha sido cambiado!";
}