function cambiarContenido(){
   const parrafo= document.getElementById("parrafo");
   parrafo.textContent= "¡El contenido ha sido cambiado!";
}